/* Copyright 2002 The MathWorks, Inc. */

#error Pre-Simulink 2.0 S-functions no are longer supported.  We suggest using one of the S-function templates and adding your algorithm code to it.

