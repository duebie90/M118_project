/* $Revision: 1.56 $
 *
 * Copyright 1994-2002 The MathWorks, Inc.
 *
 * File: rtwlog.c
 *
 * Abstract:
 *   Obsolete RTW logging file.
 */
void Obsolete_File_Remove_From_Make_Files_(void)
{
    /* 
     * This file is provided for targets that were created before
     * the release of Simulink 5.0. 
     * 
     * See release notes for for more information on how to update your 
     * targets to work with the new environment.
     */
}
